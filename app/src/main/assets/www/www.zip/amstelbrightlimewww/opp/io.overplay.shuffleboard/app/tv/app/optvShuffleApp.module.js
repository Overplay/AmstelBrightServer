/*********************************

 File:       optvShuffleApp.module
 Function:   ShuffleBoard App
 Copyright:  OverplayTV
 Date:       10.2.2015
 Author:     mkahn

 **********************************/


var app = angular.module('optvShuffleApp', [
    'ngOpTVApi'
]);


