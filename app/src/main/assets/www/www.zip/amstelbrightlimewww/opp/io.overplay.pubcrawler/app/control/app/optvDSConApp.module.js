/*********************************

 File:       optvDSConApp.module
 Function:   Base App
 Copyright:  OverplayTV
 Date:       4/10/15
 Author:     mkahn

 **********************************/


var app = angular.module('optvDSConApp', [
    'ngOpTVApi'
]);


